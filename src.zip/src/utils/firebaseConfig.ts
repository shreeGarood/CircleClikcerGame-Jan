import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAmQSZApqIoYw3Y6rl7vB1GGhA4AdZRmkc",
    authDomain: "bucketlistify-c19888.firebaseapp.com",
    projectId: "bucketlistify-c19888",
    storageBucket: "bucketlistify-c19888.firebasestorage.app",
    messagingSenderId: "463354720498",
    appId: "1:463354720498:web:92bee962891771cc4fa06b"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore
export const db = getFirestore(app);
